import os
import logging
from telegram import Update
from telegram.constants import ChatMemberStatus
from telegram.ext import Application, CommandHandler, MessageHandler, ChatMemberHandler, ContextTypes, filters

TOKEN = os.getenv("BOT_TOKEN")
if not TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is missing.")

logging.basicConfig(level=logging.INFO)
protection = {}

async def admin(update):
    if not update.effective_user or not update.effective_chat:
        return False
    m = await update.effective_chat.get_member(update.effective_user.id)
    return m.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 بوت الحماية يعمل!\n\n"
        "/on - تفعيل الحماية\n"
        "/off - إيقاف الحماية\n"
        "/status - حالة الحماية\n"
        "/id - آيدي المجموعة"
    )

async def on_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin(update):
        await update.message.reply_text("❌ للمشرفين فقط.")
        return
    protection[update.effective_chat.id] = True
    await update.message.reply_text("🛡️ تم تفعيل الحماية.")

async def off_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await admin(update):
        await update.message.reply_text("❌ للمشرفين فقط.")
        return
    protection[update.effective_chat.id] = False
    await update.message.reply_text("🔓 تم إيقاف الحماية.")

async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    enabled = protection.get(update.effective_chat.id, False)
    await update.message.reply_text("🛡️ الحماية: " + ("مفعلة ✅" if enabled else "متوقفة ❌"))

async def id_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"🆔 آيدي المجموعة: {update.effective_chat.id}")

async def protect(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg, chat = update.effective_message, update.effective_chat
    if not msg or not chat or not protection.get(chat.id, False):
        return
    if update.effective_user:
        try:
            m = await chat.get_member(update.effective_user.id)
            if m.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER):
                return
        except Exception:
            pass
    text = (msg.text or msg.caption or "").lower()
    markers = ("http://", "https://", "t.me/", "telegram.me/", "www.", "bit.ly/", "tinyurl.com/")
    if any(x in text for x in markers):
        try:
            await msg.delete()
            await chat.send_message("⚠️ تم حذف رسالة تحتوي على رابط.")
        except Exception as e:
            logging.warning("Delete failed: %s", e)

async def welcome(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.chat_member:
        return
    old = update.chat_member.old_chat_member.status
    new = update.chat_member.new_chat_member.status
    if new in (ChatMemberStatus.MEMBER, ChatMemberStatus.RESTRICTED) and old in (ChatMemberStatus.LEFT, ChatMemberStatus.BANNED):
        user = update.chat_member.new_chat_member.user
        try:
            await update.effective_chat.send_message(
                f"👋 أهلاً بك {user.mention_html()}!\n🛡️ يرجى الالتزام بقوانين المجموعة.",
                parse_mode="HTML"
            )
        except Exception:
            pass

app = Application.builder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("on", on_cmd))
app.add_handler(CommandHandler("off", off_cmd))
app.add_handler(CommandHandler("status", status_cmd))
app.add_handler(CommandHandler("id", id_cmd))
app.add_handler(ChatMemberHandler(welcome, ChatMemberHandler.CHAT_MEMBER))
app.add_handler(MessageHandler(filters.TEXT | filters.CAPTION, protect))

if __name__ == "__main__":
    app.run_polling(allowed_updates=Update.ALL_TYPES)
