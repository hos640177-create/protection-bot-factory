# Protection Bot Factory

Telegram group protection bot for Railway.

Features:
- /start
- /on and /off (admins only)
- /status
- /id
- Basic link protection
- Welcome messages

Railway environment variable:
BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN

Never put your bot token in GitHub files.
